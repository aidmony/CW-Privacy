bwt.py
